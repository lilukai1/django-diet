Cufon.replace('h1 a', { fontFamily: 'Coolvetica', hover:true});
Cufon.replace('ul.menu li a, .font-1, .font-2, .font-3, h2', { fontFamily: 'Asap', hover:true});
Cufon.replace('.banner a, .search_button, .button', { fontFamily: 'Kozuka_M', hover:true});